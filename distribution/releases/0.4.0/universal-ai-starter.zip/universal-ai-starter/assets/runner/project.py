"""Large goal entry: one Sol plan, sequential Rev-selected implementation tasks."""
if __package__ in (None, ''):
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from runner.cli import main
else:
    from .cli import main

if __name__ == '__main__':
    raise SystemExit(main())
