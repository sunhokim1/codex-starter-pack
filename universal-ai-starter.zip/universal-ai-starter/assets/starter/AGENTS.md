# Strong models, thin harness

요구사항에 필요한 사실이 없을 때 `PROJECT.md`를 읽는다. 이미 읽은 지침과 설정은 변경되지 않았으면
세션 중 재사용한다. 관련 subsystem의 코드·테스트와
해당 영역의 nested `AGENTS.md`는 작업에 필요하면 읽는다. 기존 구조를 존중하고 관련 검증을 수행한다.

## Repository map

| Major subsystem | Entry point | Tests | Docs / schema | Nested AGENTS.md |
| --- | --- | --- | --- | --- |
| Application | Not initialized. | — | — | — |
| UI / Design | Not initialized. | — | — | — |
| Data / Storage | Not initialized. | — | — | — |
| Services / Backend | Not initialized. | — | — | — |
| Tests | Not initialized. | — | — | — |
| Infrastructure | starter 배포: scripts/package_starter.py (원본 관리 저장소만) | tests/test_package_starter.py (원본만) | distribution/manifest.json, scripts/README.md | — |

해당 영역 작업 시 map이 연결한 nested AGENTS.md부터 읽는다. 개별 파일 목록은 기록하지 않는다.
새 subsystem이나 중요한 architecture boundary가 생길 때 map을 갱신하고,
주요 entry point/tests/docs/schema/nested 지침의 경로가 바뀌면 기존 링크를 바로잡는다.
작은 helper/component 추가에는 map 또는 문서 갱신을 요구하지 않는다.

## 작업과 설정

- `.ai/models.yaml`은 worker/main/escalation의 실제 모델 매핑 기준이다. 현재 채팅 모델은 자동 전환되지 않는다.
- `.ai/routing.yaml`은 단독 모델 선택·기본 reasoning·실패 시 순차 승격 기준이다. 선택한 모델이 직접 구현과 검증을 맡는다. YAML은 현재 채팅 모델을 전환하지 않는다.
- `.ai/verification.yaml`은 프로젝트에 설정된 검증 명령이다. 미설정·미실행·실패를 구분하며, 설정되지 않은 검증은 통과로 보고하지 않는다.
- `.ai/config.yaml`의 선택 기능은 비활성이다. 별도 orchestration이나 이력 기록을 요구하지 않는다.

완료하려면 요구사항을 충족하고 관련 실제 검증이 통과해야 한다. 설정된 명령 중 사용 가능한 것만 실행하며,
명령이 없으면 수동 점검 결과와 검증 한계를 밝힌다.

고정 기본 모델 없이 구현 전에 작업 적합도와 예상 전체 시간·토큰·재작업 위험·검증 신뢰도를 짧게 판단한다.
요구사항·범위가 명확하고 기존 코드 패턴으로 해결되며, 변경이 국소적/독립적이고 실패 영향이 작고
복구가 쉬우며 검증이 명확하고 재작업 위험이 낮으면 Luna(worker)를 선택한다.
해석·설계·복잡한 원인 분석, subsystem 의존성, architecture/데이터 구조 변경, 높은 실패 영향 또는
Luna 실패로 전체 비용이 늘 가능성이 크면 Sol(main)을 선택한다. 판단 근거가 부족하거나 실패 영향이 크면 Sol을 추천한다.
파일 수나 요청 길이만으로 선택하지 않으며 별도 분류 호출·점수 계산을 요구하지 않는다. 사용자가 지정한 모델을 우선한다.
Luna/Sol은 독립 실행 모델이며 worker/main은 매핑 이름이다. 조율자와 하위 구현자의 분업이나 고정 상하 관계를 뜻하지 않는다.

Sol+Luna 조율, 하위 에이전트 배정, 자동 병렬 실행은 사용하지 않는다. 선택된 모델이 설계·구현·검토·검증을 직접 수행한다.
처음부터 Sol이 적합하면 Sol로 시작한다. 확인된 미해결 문제나 관련 검증 실패의 원인을 분석하고
현재 모델로 해결하기 어려운 경우에만 Luna → Sol → Astra 순서로 한 단계 승격한다.
환경 오류·일시적 도구 실패·확신 부족만으로 승격하지 않는다.
승격할 때 목표·관련 파일·시도·검증 결과·남은 문제만 전달한다. 별도 하위 에이전트를 생성해 모델 전환을 대신하지 않는다.
모델 전환을 실행 환경에서 지원하지 않으면 현재 모델을 유지하며 실제 사용 모델·추천 모델·추천 이유를 밝히고 사용자 선택을 안내한다.
실행하지 않은 모델이나 승격을 실행했다고 보고하지 않는다.

관련된 읽기와 수정을 묶어 처리하되 도구 호출 횟수 제한을 두지 않는다. 실제 실행된 검증 증거를 확인하며,
코드 변경·실패·중요한 우려 없이 동일한 최종 상태의 검사를 반복하지 않는다. 완료 시 변경 내용·실제 검증·미해결 문제를 간결히 보고한다.
